namespace WinFormsApp3
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			cts = new CancellationTokenSource();
		}

		private void button1_Click(object sender, EventArgs e)
		{

		}
		Task<int> task = LRP();
		CancellationTokenSource cts;
		private void Form1_Load(object sender, EventArgs e)
		{

		}
		static Task<int> LRP()
		{
			return Task.Run(async () =>
			{
				
				Thread.Sleep(5000);
				return 100;
			});

		}

		private void button2_Click(object sender, EventArgs e)
		{
			label1.Text = task.IsCompleted.ToString();
		}

		private void button1_Click_1(object sender, EventArgs e)
		{

		}
	}
}
