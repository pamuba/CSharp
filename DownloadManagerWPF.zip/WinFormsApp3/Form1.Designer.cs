﻿namespace WinFormsApp3
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			button2 = new Button();
			label1 = new Label();
			button1 = new Button();
			SuspendLayout();
			// 
			// button2
			// 
			button2.Font = new Font("Segoe UI", 12F);
			button2.Location = new Point(228, 168);
			button2.Name = "button2";
			button2.Size = new Size(90, 31);
			button2.TabIndex = 1;
			button2.Text = "Check Child";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Segoe UI", 12F);
			label1.Location = new Point(315, 98);
			label1.Name = "label1";
			label1.Size = new Size(52, 21);
			label1.TabIndex = 2;
			label1.Text = "label1";
			// 
			// button1
			// 
			button1.Font = new Font("Segoe UI", 12F);
			button1.Location = new Point(398, 168);
			button1.Name = "button1";
			button1.Size = new Size(87, 35);
			button1.TabIndex = 3;
			button1.Text = "Cancel";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click_1;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Controls.Add(button1);
			Controls.Add(label1);
			Controls.Add(button2);
			Name = "Form1";
			Text = "Form1";
			Load += Form1_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion
		private Button button2;
		private Label label1;
		private Button button1;
	}
}
