﻿using System.Diagnostics;

//using var client  = new HttpClient();
//var taskPokemonListJson = client.GetStringAsync("https://cdn.rawgit.com/Naramsim/ninjask/master/data/api/v2/pokemon/1/index.json");

//var taskGetFirstPokemonUrl = taskPokemonListJson.ContinueWith(t => {
//    var result = t.Result;
//    var doc = JsonDocument.Parse(result);
//    JsonElement root = doc.RootElement;
//    JsonElement results = root.GetProperty("abilities");
//    JsonElement firstPokemon = results[0];
//    return firstPokemon.GetProperty("url").ToString();
//});

//var taskGetFirstPokemonDetailsJson = taskGetFirstPokemonUrl.ContinueWith(t => {
//    var result = t.Result;
//    return client.GetStringAsync(result);
//}).Unwrap();

//taskGetFirstPokemonDetailsJson.ContinueWith(t => { 

//});
//1. Data partition - executed by different loops
//2. Mostly uses threwad pool threads
//3. Makes best decisions by itself
//4. Blocking Calls

//int[] array = Enumerable.Range(0,100).ToArray();

//int sum = 0;

//object lockSum = new object();

//ParallelLoopResult result = new ParallelLoopResult();

//try {

//	result = Parallel.For(0, array.Length, (i, state) => {

//		lock (lockSum)
//		{
//			if (!state.IsExceptional)
//			{
//				//if (i == 65)
//				//	state.Break();

//				sum += array[i];
//				Console.WriteLine($"Current Task id: {Task.CurrentId} {Thread.CurrentThread.IsThreadPoolThread}");
//			}
//		}
//	});
//}
//catch (AggregateException ex) {
//	Console.WriteLine("Exception Occured");
//}

//Console.WriteLine($"Sum:{sum}");
//Console.ReadLine();
//using var cts = new CancellationTokenSource();
//var token = cts.Token;

//var task = Task.Run(Work,token);

//Console.WriteLine("To cancel press 'c'");
//var input = Console.ReadLine();
//if(input == "c")
//	cts.Cancel();

////Aggregate Exp
//task.Wait();
//Console.WriteLine("Task Status: "+task.Status);
//Console.ReadLine();

//void Work() {
//    Console.WriteLine("Started doing some work");

//	//for (int i = 0; i < 100000; i++) {
//	//       Console.WriteLine(DateTime.Now);
//	//       if (token.IsCancellationRequested) {
//	//           Console.WriteLine("Cancellation Requested");
//	//           token.ThrowIfCancellationRequested();
//	//       }
//	//       Thread.SpinWait(3000000);
//	//   }

//	var options = new ParallelOptions { CancellationToken = cts.Token};
//	try {
//		Parallel.For(0, 100000, options, i => {
//			Console.WriteLine(DateTime.Now);
//			Thread.SpinWait(30000000);
//		});
//	}
//	catch (OperationCanceledException ex) {
//        Console.WriteLine("Work Cancelled");
//    }
//    Console.WriteLine("Work is done");
//}






//int[] array = Enumerable.Range(0, 100000).ToArray();
//int sum = 0;
//object lockSum = new object();

//Parallel.For(
//	0,
//	array.Length,
//	() => 0,
//	(i, state, tls) => {
//		tls += array[i];
//		return tls;
//	},
//	tls => {
//		lock (lockSum) { 
//			sum += tls;
//			Console.WriteLine(Task.CurrentId);
//		}
//	}
//);

//Console.WriteLine("SUM:"+sum);
//Console.ReadLine();

//Wait  + Result

//ConcurrentQueue

//Blocking Collection
//using System;
//using System.Collections.Concurrent;
//namespace ConcurrentBagDemo
//{
//	class Program
//	{
//		static void Main()
//		{
//			// Creating an Instance of BlockingCollection Class without Capacity
//			BlockingCollection<int> blockingCollection = new BlockingCollection<int>()
//			{
//				10,
//				20
//			};

//			//Accessing the BlockingCollection using For Each loop
//			Console.WriteLine("All BlockingCollection Elements");
//			foreach (var item in blockingCollection)
//			{
//				Console.WriteLine(item);
//			}

//			//Removing item using Take Method
//			int Result1 = blockingCollection.Take();
//			Console.WriteLine($"\nItem Removed By Take Method: {Result1}");

//			//Removing item using TryTake Method
//			if (blockingCollection.TryTake(out int Result2, TimeSpan.FromSeconds(1)))
//			{
//				Console.WriteLine($"\nItem Removed By TryTake Method: {Result2}");
//			}
//			else
//			{
//				Console.WriteLine("\nNo Item Removed By TryTake Method");
//			}

//			//No More Elements in the Collections and Trying to Remove Item using TryTake Method
//			if (blockingCollection.TryTake(out int Result3, TimeSpan.FromSeconds(1)))
//			{
//				Console.WriteLine($"\nItem Removed By TryTake Method: {Result3}");
//			}
//			else
//			{
//				Console.WriteLine("\nNo Item Removed By TryTake Method");
//			}

//			Console.ReadKey();
//		}
//	}
//}

//using System;
//using System.Collections.Concurrent;
//using System.Threading.Tasks;
//namespace ConcurrentBagDemo
//{
//	class Program
//	{
//		static void Main()
//		{
//			BlockingCollection<int> blockingCollection = new BlockingCollection<int>();

//			//Thread 1 (Producer Thread) Adding Item to blockingCollection
//			Task producerThread = Task.Factory.StartNew(() =>
//			{
//				for (int i = 0; i < 10; ++i)
//				{
//					blockingCollection.Add(i);
//				}

//				//Mark blockingCollection will not accept any more additions
//				blockingCollection.CompleteAdding();
//			});

//			//Thread 2 (Consumer Thread) Removing Item from blockingCollection and Printing on the Console
//			Task consumerThread = Task.Factory.StartNew(() =>
//			{
//				//Loop will continue as long as IsCompleted returns false
//				while (!blockingCollection.IsCompleted)
//				{
//					int item = blockingCollection.Take();
//					Console.Write($"{item} ");
//				}
//			});

//			Task.WaitAll(producerThread, consumerThread);
//			Console.ReadKey();
//		}
//	}
//}


//using System;
//using System.Collections.Concurrent;
//using System.Threading;
//using System.Threading.Tasks;
//namespace ConcurrentBagDemo
//{
//	class Program
//	{
//		static void Main()
//		{
//			BlockingCollection<int> blockingCollection = new BlockingCollection<int>();

//			//Thread 1 (Producer Thread) Adding Item to blockingCollection
//			Task producerThread = Task.Factory.StartNew(() =>
//			{
//				for (int i = 0; i < 10; ++i)
//				{
//					Thread.Sleep(TimeSpan.FromSeconds(1));
//					blockingCollection.Add(i);
//				}

//				//Mark blockingCollection will not accept any more additions
//				blockingCollection.CompleteAdding();
//			});

//			foreach (int item in blockingCollection.GetConsumingEnumerable())
//			{
//				Console.Write($"{item} ");
//			}
//			Console.ReadKey();
//		}
//	}
//}


//using System;
//using System.Collections.Concurrent;
//using System.Threading;
//using System.Threading.Tasks;
//namespace ConcurrentBagDemo
//{
//	class Program
//	{
//		static void Main()
//		{
//			BlockingCollection<int>[] producers = new BlockingCollection<int>[3];
//			producers[0] = new BlockingCollection<int>(boundedCapacity: 10);
//			producers[1] = new BlockingCollection<int>(boundedCapacity: 10);
//			producers[2] = new BlockingCollection<int>(boundedCapacity: 10);

//			Task t1 = Task.Factory.StartNew(() =>
//			{
//				for (int i = 1; i <= 10; ++i)
//				{
//					producers[0].Add(i);
//					Thread.Sleep(100);
//				}
//				producers[0].CompleteAdding();
//			});

//			Task t2 = Task.Factory.StartNew(() =>
//			{
//				for (int i = 11; i <= 20; ++i)
//				{
//					producers[1].Add(i);
//					Thread.Sleep(150);
//				}
//				producers[1].CompleteAdding();
//			});

//			Task t3 = Task.Factory.StartNew(() =>
//			{
//				for (int i = 21; i <= 30; ++i)
//				{
//					producers[2].Add(i);
//					Thread.Sleep(250);
//				}
//				producers[2].CompleteAdding();
//			});

//			while (!producers[0].IsCompleted || !producers[1].IsCompleted || !producers[2].IsCompleted)
//			{
//				BlockingCollection<int>.TryTakeFromAny(producers, out int item, TimeSpan.FromSeconds(1));
//				if (item != default(int))
//				{
//					Console.Write($"{item} ");
//				}
//			}
//			Console.ReadKey();
//		}
//	}
//}


//BlockingCollection<T> is a thread - safe collection class that provides the following features:
//An implementation of the Producer-Consumer pattern.
//Concurrent adding and taking of items from multiple threads.
//Optional maximum capacity.
//Insertion and removal operations block when the collection is empty or full.
//Insertion and removal “try” operations that do not block or that block up to a specified period of time.
//Encapsulates any collection type that implements IProducerConsumerCollection<T>

//Concurrent Bag
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ConcurrentBagDemo
{
	class Program
	{
		static void Main()
		{
			TestBag();
			Console.ReadKey();
		}

		public static void TestBag()
		{
			List<string> MobileOrders = new List<string>();

			Task t1 = Task.Run(() => GetOrders("Pranaya", MobileOrders));
			Task t2 = Task.Run(() => GetOrders("Anurag", MobileOrders));
			Task.WaitAll(t1, t2); //Wait till both the task completed

			foreach (var mobileOrder in MobileOrders)
			{
				Console.WriteLine($"Order Placed: {mobileOrder}");
			}
		}

		private static void GetOrders(string custName, List<string> MobileOrders)
		{
			for (int i = 0; i < 3; i++)
			{
				Thread.Sleep(100);
				string order = string.Format($"{custName} Needs {i + 3} Mobiles");
				MobileOrders.Add(order);
			}
		}
	}
}



//using System;
//using System.Collections.Generic;
//using System.Threading;
//using System.Threading.Tasks;

//namespace ConcurrentBagDemo
//{
//	class Program
//	{
//		static object lockObject = new object();
//		static void Main()
//		{
//			TestBag();
//			Console.ReadKey();
//		}

//		public static void TestBag()
//		{
//			List<string> MobileOrders = new List<string>();

//			Task t1 = Task.Run(() => GetOrders("Pranaya", MobileOrders));
//			Task t2 = Task.Run(() => GetOrders("Anurag", MobileOrders));
//			Task.WaitAll(t1, t2); //Wait till both the task completed

//			foreach (var mobileOrder in MobileOrders)
//			{
//				Console.WriteLine($"Order Placed: {mobileOrder}");
//			}
//		}

//		private static void GetOrders(string custName, List<string> MobileOrders)
//		{
//			for (int i = 0; i < 3; i++)
//			{
//				Thread.Sleep(100);
//				string order = string.Format($"{custName} Needs {i + 3} Mobiles");
//				lock (lockObject)
//				{
//					MobileOrders.Add(order);
//				}
//			}
//		}
//	}
//}



//using System;
//using System.Collections.Concurrent;
//using System.Threading;
//using System.Threading.Tasks;

//namespace ConcurrentBagDemo
//{
//	class Program
//	{
//		static ConcurrentBag<int> concurrentBag = new ConcurrentBag<int>();
//		static AutoResetEvent autoEvent1 = new AutoResetEvent(false);
//		static void Main(string[] args)
//		{
//			Task thread1 = Task.Factory.StartNew(() => AddThread1Elements());
//			Task thread2 = Task.Factory.StartNew(() => AddThread2Elements());
//			Task.WaitAll(thread1, thread2);

//			Console.WriteLine("End of the Main Method");
//			Console.ReadKey();
//		}

//		public static void AddThread1Elements()
//		{
//			int[] array = { 10, 20, 30, 40 };
//			for (int i = 0; i < array.Length; i++)
//			{
//				concurrentBag.Add(array[i]);
//			}

//			//wait for second thread to add its items
//			autoEvent1.WaitOne();

//			while (concurrentBag.IsEmpty == false)
//			{
//				if (concurrentBag.TryTake(out int item))
//				{
//					Console.WriteLine($"Thread1 Reads: {item}");
//				}
//			}
//		}

//		public static void AddThread2Elements()
//		{
//			int[] array = { 50, 60, 70 };
//			for (int i = 0; i < array.Length; i++)
//			{
//				concurrentBag.Add(array[i]);
//			}
//			autoEvent1.Set();
//		}
//	}
//}

//using System;
//using System.Threading;
//using System.Threading.Tasks;

//public class Program
//{
//	private static Barrier _barrier = new Barrier(3); // 3 participants

//	public static void Main()
//	{
//		Console.WriteLine("Starting Barrier Demonstration");

//		Task task1 = Task.Run(() => DoWork("Task 1"));
//		Task task2 = Task.Run(() => DoWork("Task 2"));
//		Task task3 = Task.Run(() => DoWork("Task 3"));

//		Task.WaitAll(task1, task2, task3);

//		Console.WriteLine("Barrier Demonstration Completed");
//	}

//	public static void DoWork(string taskName)
//	{
//		Console.WriteLine($"{taskName} started");
//		Thread.Sleep(new Random().Next(1000, 3000)); // Simulate work
//		Console.WriteLine($"{taskName} waiting at barrier");

//		_barrier.SignalAndWait(); // Wait for other threads

//		Console.WriteLine($"{taskName} passed barrier");
//		Thread.Sleep(new Random().Next(1000, 3000)); // More work
//		Console.WriteLine($"{taskName} completed");
//	}
//}

//int[] array = Enumerable.Range(0, 100).ToArray();

//int sum = 0;
//object lockSum = new object();


//try
//{
//	Parallel.For(0, array.Length, (i, state) =>
//	{
//		lock (lockSum)
//		{
//			if (!state.IsStopped)
//			{
//				if (i == 65)
//					state.Stop();

//				sum += array[i];
//				Console.WriteLine(i);
//				//Console.WriteLine($"Current task id: {Task.CurrentId}; Is thread pool thread: {Thread.CurrentThread.IsThreadPoolThread}");
//			}
//		}
//	});


//}
//catch (AggregateException ex)
//{
//	Console.WriteLine(ex);
//}

//Console.WriteLine($"The sum is {sum}");

//Console.ReadLine();

//////////////////////////////////////////////////////////////

//int[] array = Enumerable.Range(0, 100).ToArray();

//int sum = 0;
//object lockSum = new object();


//try
//{
//	Parallel.For(0, array.Length, (i, state) =>
//	{
//		lock (lockSum)
//		{
//			if (state.ShouldExitCurrentIteration && state.LowestBreakIteration < i)
//				return;


//			if (i == 65)
//				state.Break();

//			sum += array[i];
//			//Console.WriteLine($"Current task id: {Task.CurrentId}; Is thread pool thread: {Thread.CurrentThread.IsThreadPoolThread}");
//			Console.WriteLine(i);
//		}
//	});


//}
//catch (AggregateException ex)
//{
//	Console.WriteLine(ex);
//}

//Console.WriteLine($"The sum is {sum}");

//Console.ReadLine();


//partial class Program
//{
//	static async Task Main(string[] args)
//	{
//		Console.WriteLine("Main Thread Start.");
//		Console.WriteLine($"Main Thread ID: {Thread.CurrentThread.ManagedThreadId}");
//		Console.WriteLine("Initiating long-running operation asynchronously...");

//		// Start the operation without blocking the Main thread 

//		Task<long> longRunningTask = StartLongOperationAsync();

//		// The Main thread is free to do other work while the task runs: 
//		Console.WriteLine("Main thread is not blocked. Enter commands here (e.g., 'status'):");

//		// Simulate application responsiveness by handling user input 
//		bool isRunning = true;
//		while (isRunning)
//		{
//			string input = Console.ReadLine();
//			if (input?.ToLower() == "status")
//			{
//				Console.WriteLine($"Status Check: Task completion status is {longRunningTask.IsCompleted}.");
//			}
//			else if (input?.ToLower() == "exit")
//			{
//				isRunning = false;
//				break;
//			}
//			else if (string.IsNullOrEmpty(input))
//			{
//				continue;
//			}
//			else
//			{
//				Console.WriteLine($"Unknown command: '{input}'. Try 'status' or 'exit'.");
//			}
//		}
//		// Await the result of the task when needed (or before the app closes) 
//		Console.WriteLine("\nAwaiting the final result of the long operation...");
//		long result = await longRunningTask;
//		Console.WriteLine($"\nOperation completed. Total duration: {result} milliseconds.");

//		Console.WriteLine("Main Thread End.");
//	}

//	static Task<long> StartLongOperationAsync()
//	{
//		//Task.Run offloads the synchronous work to the ThreadPool. 
//		// The calling method (Main) immediately gets control back. 
//		return Task.Run(async () =>
//		{
//			Console.WriteLine($"\n--- Operation started on Thread ID: {Thread.CurrentThread.ManagedThreadId} (ThreadPool) --- {Thread.CurrentThread.IsThreadPoolThread}");
//			Stopwatch stopwatch = Stopwatch.StartNew();
//			const int iterations = 20;
//			for (int i = 0; i < iterations; i++)
//			{
//				// In a real app, replace this with CPU-intensive work (e.g., heavy calculation, file I/O) 
//				await Task.Delay(1000); // Simulate 1 second of work 
//				Console.WriteLine($"--- Operation step {i + 1}/{iterations} completed... ---");
//			}

//			stopwatch.Stop();
//			Console.WriteLine("--- Operation finished in background ---");
//			return stopwatch.ElapsedMilliseconds;
//		});
//	}
//}


class Program
{
    async static Task Main(string[] args)
    {
        Console.WriteLine("1. Main Starts"+Thread.CurrentThread.ManagedThreadId);
        Task<int> task = LRP();
		//task.IsCompleted
		Console.WriteLine("2. Main Starts" + Thread.CurrentThread.ManagedThreadId);
		//while (true) { Console.WriteLine("Main "); }
        Console.WriteLine(task.Result);
        Console.WriteLine("Main Ends");
    }

    static Task<int> LRP()
    {
		Console.WriteLine("1.Child Starts" + Thread.CurrentThread.ManagedThreadId);
		return Task.Run(async () => {
			Console.WriteLine("2.Child Starts" + Thread.CurrentThread.ManagedThreadId);
            //await
			Console.WriteLine("Child Task Starts");
			Thread.Sleep(5000);
			Console.WriteLine("Child Task Ends");
			return 100;
		});
        
    }
}