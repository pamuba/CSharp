﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace DownloadManagerDemo
{
    // Optional shared stats using ReaderWriterLockSlim
    public class DownloadStats
    {
        private readonly ReaderWriterLockSlim _rwLock = new ReaderWriterLockSlim();
        private readonly Dictionary<string, int> _progressByFile = new Dictionary<string, int>();
        private int _completedCount;

        public void UpdateProgress(string fileName, int progress)
        {
            _rwLock.EnterWriteLock();
            try
            {
                _progressByFile[fileName] = progress;
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }

        public void MarkCompleted(string fileName)
        {
            _rwLock.EnterWriteLock();
            try
            {
                _progressByFile[fileName] = 100;
                _completedCount++;
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }

        public (int completed, int total, double avgProgress) Snapshot()
        {
            _rwLock.EnterReadLock();
            try
            {
                int total = _progressByFile.Count;
                double avg = total == 0 ? 0 : _progressByFile.Values.Average();
                return (_completedCount, total, avg);
            }
            finally
            {
                _rwLock.ExitReadLock();
            }
        }
    }

    public class DownloadTask
    {
        public string FileName { get; }
        public int SizeInMB { get; }
        public int Progress { get; private set; }

        private readonly int _chunkPercent; // e.g., 10% increments
        private readonly int _delayMsPerChunk; // simulate work

        public DownloadTask(string fileName, int sizeInMB, int chunkPercent = 10, int delayMsPerChunk = 200)
        {
            FileName = fileName;
            SizeInMB = sizeInMB;
            Progress = 0;
            _chunkPercent = chunkPercent;
            _delayMsPerChunk = delayMsPerChunk;
        }

        public async Task StartAsync(
            SemaphoreSlim semaphore,
            CancellationToken token,
            Barrier barrier,
            List<string> completedLog,
            object logLock,
            DownloadStats stats = null)
        {
            await semaphore.WaitAsync(token);
            try
            {
                for (int i = 0; i <= 100; i += _chunkPercent)
                {
                    token.ThrowIfCancellationRequested();

                    Progress = i;
                    stats?.UpdateProgress(FileName, Progress);
                    Console.WriteLine($"{FileName} progress: {Progress}%");

                    // Barrier sync at 25%, 50%, 75%, 100% phases
                    if (barrier != null && (Progress % 25 == 0))
                    {
                        try
                        {
                            barrier.SignalAndWait(token);
                        }
                        catch (OperationCanceledException)
                        {
                            // If cancellation occurs during barrier wait, break gracefully
                            Console.WriteLine($"{FileName} canceled at barrier phase.");
                            throw;
                        }
                    }

                    await Task.Delay(_delayMsPerChunk, token);
                }

                Console.WriteLine($"{FileName} completed!");
                stats?.MarkCompleted(FileName);

                // Thread-safe logging of completion
                lock (logLock)
                {
                    completedLog.Add(FileName);
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine($"{FileName} canceled.");
            }
            finally
            {
                semaphore.Release();
            }
        }
    }

    public static class Program
    {
        public static async Task Main()
        {
            var channel = Channel.CreateBounded<int>(7);
            // Level 2: Concurrency control
            var semaphore = new SemaphoreSlim(3);

            // Level 4: Cancellation support
            var cts = new CancellationTokenSource();

            // Level 5: Barrier progress sync
            // We’ll set participant count dynamically per batch of active downloads.
            // For simplicity, we’ll start with 3 participants (matching semaphore).
            var barrier = new Barrier(3, b =>
            {
                int milestone = (int)(b.CurrentPhaseNumber + 1) * 25;
                Console.WriteLine($"== All active downloads reached {milestone}% ==");
            });

            // Level 3: Thread-safe completion log
            var completed = new List<string>();
            var logLock = new object();

            // Optional shared stats
            var stats = new DownloadStats();

            // Level 1: Thread spawning
            var downloads = new List<DownloadTask>
            {
                new DownloadTask("File_A.zip", 120),
                new DownloadTask("File_B.iso", 700),
                new DownloadTask("File_C.mp4", 350),
                new DownloadTask("File_D.pdf", 40),
                new DownloadTask("File_E.tar", 500),
                new DownloadTask("File_F.jpg", 15),
                new DownloadTask("File_G.mov", 800),
                new DownloadTask("File_H.docx", 25),
                new DownloadTask("File_I.bin", 260),
                new DownloadTask("File_J.pkg", 420),
            };

            // Register initial participants for barrier (up to 3 concurrent)
            // Note: Barrier participants should match the number of tasks that will sync.
            // We’ll manage barrier participants by batches of up to 3 tasks.
            // For simplicity, we keep barrier at 3 and let tasks beyond the first 3 skip barrier until they start.
            // Alternatively, you can create per-batch barriers.

            Console.WriteLine("Starting downloads...");

            // Kick off tasks
            var tasks = downloads.Select(d => Task.Run(() =>
                d.StartAsync(semaphore, cts.Token, barrier, completed, logLock, stats))).ToList();

            // Demonstrate cancellation: cancel one after a short delay
            _ = Task.Run(async () =>
            {
                await Task.Delay(1500);
                Console.WriteLine(">>> Requesting cancellation for one download...");
                cts.Cancel(); // This will cancel whichever task hits a cancellation check next
            });

            try
            {
                await Task.WhenAll(tasks);
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("One or more downloads were canceled.");
            }

            // Print completion log
            Console.WriteLine("\n=== Completed Downloads (Thread-safe log) ===");
            lock (logLock)
            {
                foreach (var file in completed)
                {
                    Console.WriteLine($"- {file}");
                }
            }

            // Print stats snapshot
            var (completedCount, totalCount, avgProgress) = stats.Snapshot();
            Console.WriteLine($"\n=== Stats ===");
            Console.WriteLine($"Completed: {completedCount}/{totalCount}");
            Console.WriteLine($"Average progress: {avgProgress:F1}%");

            Console.WriteLine("\nAll tasks finished. Press any key to exit.");
            Console.ReadKey();
        }
    }
}
