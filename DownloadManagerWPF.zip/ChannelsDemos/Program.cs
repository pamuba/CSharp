﻿//using System.Threading.Channels;
//class Program
//{
//    static CancellationTokenSource cts = new CancellationTokenSource();

//    static async Task Main()
//    {



//        // Create a new channel for strings
//        var channel = Channel.CreateUnbounded<string>();
//        // Start a background thread for sending messages
//        var senderTask = Task.Run(async () =>
//        {
//            var writer = channel.Writer;
//            for (int i = 1; i <= 20; i++)
//            {
//                await writer.WriteAsync($"Message {i}");
//                await Task.Delay(100); // delay to illustrate.
//            }
//            writer.Complete();
//        });
//        // main thread reads messages from the channel
//        var reader = channel.Reader;

//        _ = Task.Run(async () =>
//        {
//            Console.Out.WriteLine("Press 'c' to cancel.");
//            var input = Console.ReadLine();
//            if (input == "c")
//            {
//                cts.Cancel();
//            }
//        });
//        try
//        {
//            await foreach (var message in reader.ReadAllAsync(cts.Token)) //10 -- 5
//            {
//                Console.WriteLine($"Received: {message}");
//                Console.Out.WriteLine(channel.Reader.Count);
//            }
//        }
//        catch (Exception ex)
//        {
//            Console.Out.WriteLine("Operation Cancelled");
//        }



//        Console.Out.WriteLine(channel.Reader.Count);
//        // Wait for the background thread to complete
//        await senderTask;

//        Console.WriteLine("Main Ends");
//    }
//}