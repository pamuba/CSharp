﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChannelsDemos
{
    public class IAsyncEnumerableDemo
    {
        static async Task Main(string[] args)
        {
            await foreach (int number in GetNumbersAsync())
            {
                Console.WriteLine(number); // Process each number as it arrives
            }
        }

        //5 secs
        public static async IAsyncEnumerable<int> GetNumbersAsync()
        {
            for (int i = 1; i <= 5; i++)
            {
                await Task.Delay(1000); // Simulate asynchronous work (e.g., network request)
                yield return i; // Return an item as it becomes available
            }
        }
    }
}
