﻿
namespace DownloadManagerWPF.Services
{
    using DownloadManagerWPF.Models;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    namespace DownloadManagerUI.Services
    {
        public class DownloadService
        {
            private readonly SemaphoreSlim _semaphore;
            private readonly object _logLock = new object();
            private readonly List<string> _completedLog = new List<string>();

            // Optional barrier to sync milestones among active downloads
            private readonly Barrier _barrier;

            public event Action<string> OnMilestone; // e.g., "All active reached 25%"

            public DownloadService(int maxConcurrent = 3, int barrierParticipants = 3)
            {
                _semaphore = new SemaphoreSlim(maxConcurrent);
                _barrier = new Barrier(barrierParticipants, b =>
                {
                    int milestone = (int)(b.CurrentPhaseNumber + 1) * 25;
                    OnMilestone?.Invoke($"All active downloads reached {milestone}%");
                });
            }

            public IReadOnlyList<string> CompletedLog
            {
                get
                {
                    lock (_logLock) return _completedLog.AsReadOnly();
                }
            }

            public async Task StartAsync(
                DownloadItem item,
                IProgress<int> progress,
                CancellationToken token)
            {
                await _semaphore.WaitAsync(token);
                try
                {
                    item.IsRunning = true;
                    item.Status = "Downloading";

                    for (int p = 0; p <= 100; p += 5)
                    {
                        token.ThrowIfCancellationRequested();
                        item.Progress = p;
                        progress?.Report(p);

                        // Optional barrier sync at 25% increments
                        if (p % 25 == 0)
                        {
                            try
                            {
                                //_barrier.SignalAndWait(token);
                            }
                            catch (OperationCanceledException)
                            {
                                // If canceled while waiting at barrier, propagate
                                throw;
                            }
                        }

                        await Task.Delay(150, token); // simulate work
                    }

                    item.Status = "Completed";
                    lock (_logLock) 
                        _completedLog.Add(item.FileName);
                }
                catch (OperationCanceledException)
                {
                    item.Status = "Canceled";
                }
                catch (Exception ex)
                {
                    item.Status = $"Error: {ex.Message}";
                }
                finally
                {
                    item.IsRunning = false;
                    _semaphore.Release();
                }
            }

            public void Cancel(DownloadItem item)
            {
                if (!item.Cts.IsCancellationRequested)
                    item.Cts.Cancel();
            }
        }
    }
}
