﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DownloadManagerWPF.Models
{
    public class DownloadItem : INotifyPropertyChanged
    {
        private int _progress;
        private string _status;
        private bool _isRunning;
        public string FileName { get; set; }
        public int SizeInMB { get; set; }
        public int Progress { 
            get => _progress; 
            set { _progress = value; OnPropertyChanged(); } 
        }
        public string Status { 
            get => _status; 
            set { _status = value; OnPropertyChanged(); } 
        }
        public bool IsRunning { get => _isRunning; set { _isRunning = value; OnPropertyChanged(); } } 
        // Per-item cancellation
        public CancellationTokenSource Cts { get; set; } = new CancellationTokenSource(); 
        public event PropertyChangedEventHandler PropertyChanged; 
        private void OnPropertyChanged([CallerMemberName] string name = null) 
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name)); 
    }
}
