﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DownloadManagerWPF.Models;
using DownloadManagerWPF.Services.DownloadManagerUI.Services;

namespace DownloadManagerWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<DownloadItem> Downloads { get; } = new ObservableCollection<DownloadItem>();
        public ObservableCollection<string> Completed { get; } = new ObservableCollection<string>();
        public string MilestoneMessage { get; set; }
        private readonly DownloadService _service;
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            _service = new DownloadService(maxConcurrent: 3, barrierParticipants: 3);
            _service.OnMilestone += msg =>
            {
                // Update milestone on UI thread
                Dispatcher.Invoke(() => MilestoneMessage = msg);
            };
            SeedDownloads();
        }

        private void SeedDownloads()
        {
            Downloads.Add(new DownloadItem { FileName = "File_A.zip", SizeInMB = 120, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_B.iso", SizeInMB = 700, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_C.mp4", SizeInMB = 350, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_D.pdf", SizeInMB = 40, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_E.tar", SizeInMB = 500, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_F.jpg", SizeInMB = 15, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_G.mov", SizeInMB = 800, Status = "Ready" });
            Downloads.Add(new DownloadItem { FileName = "File_H.docx", SizeInMB = 25, Status = "Ready" });
        }
        private async Task StartItemAsync(DownloadItem item)
        {
            if (item.IsRunning) return;
            // Per-item progress marshaled to UI via SynchronizationContext
            var progress = new Progress<int>(p =>
            {
                // item.Progress is bound; setting triggers UI update
                item.Progress = p;
            });
            var token = item.Cts.Token;
            await _service.StartAsync(item, progress, token);
            // Update completed list after finish
            if (item.Status == "Completed")
            { 
                Completed.Add(item.FileName); 
            }
        }
        private async void StartItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.DataContext is DownloadItem item)
            { await StartItemAsync(item); }
        }
        private void CancelItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement fe && fe.DataContext is DownloadItem item)
            { _service.Cancel(item); }
        }
        private async void StartAll_Click(object sender, RoutedEventArgs e)
        {
            var tasks = Downloads.Select(StartItemAsync).ToList();
            try { 
                await Task.WhenAll(tasks); 
            }
            catch (OperationCanceledException)
            {
                // Some items may be canceled; statuses reflect that
            }
        }
        private void CancelAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in Downloads)
            { _service.Cancel(item); }
        }
    }
}